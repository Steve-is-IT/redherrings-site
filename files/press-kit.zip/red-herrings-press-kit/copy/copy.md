# Copy, by length

Approved descriptions of Red Herrings, by length. Use any of them as written.

## Name
Red Herrings

## Tagline (43 characters)
Forensics and IR labs that grade themselves

## One line (111 characters)
Digital forensics and incident response labs with a different case for every student and a verified answer key.

## Short (156 characters)
Generate per-student digital forensics and incident response labs with verified answer keys, one-click grading and LMS export. Runs offline on your machine.

## Medium (about 60 words)
Red Herrings generates digital forensics and incident response lab exercises for a whole class at once. Every student gets a different variant of the case: names, timestamps, hashes and most answers change per student, so a copied answer sheet scores about a quarter of the points. Each fact answer is re-derived from the generated evidence before the lab ships. Grades export to Canvas, Blackboard, Moodle and D2L.

## Long (about 210 words)
Red Herrings is a desktop application for Windows, macOS and Linux that turns one authored case into an individually generated lab for every student. The evidence is written in the formats the standard tools open: disk images, registry hives, Windows event logs, Windows crash dumps and Linux LiME memory images that Volatility 3 reads, packet captures, mobile extractions, cloud audit logs, and EDR and SIEM exports. Names, timestamps, hashes and addresses change per student from a single seed, and so do about four in five answers, so a shared answer sheet scores about a quarter of the points. Every fact answer is verified against the generated files before release, by independent parsers for most formats and Red Herrings' own reader for memory images.

Grading takes one click, with tolerances for hashes and timestamps and an explanation for every score, and exports to Canvas, Blackboard, Moodle and D2L or posts over LTI 1.3. The library holds 83 cases, from 24 free single-artifact First Looks to multi-hour capstones, with learning pathways for GIAC, CompTIA and SANS prep, incident-response cases mapped to MITRE ATT&CK, two course packs with full syllabi, a guided mode for stuck learners and timed exams with integrity logging. Everything runs on the instructor's own machine; no student data leaves it. First Look cases run free with no key or account, and a 30-day trial key is emailed on request.

## Who it's for (one line each)
- Instructors teaching a digital forensics or incident response class.
- Departments and programs running a syllabus across several instructors.
- Security teams training analysts with timed drills and CTFs.
- Self-learners preparing for GCFE, GCFA, GCIH or CySA+.

## Categories
Education, Cybersecurity, Digital Forensics, Incident Response, E-Learning, Training, Course Authoring, Lab Management

## Tags
digital forensics, incident response, DFIR, cybersecurity education, forensics lab, SOC training, GCFE, GCIH, CompTIA CySA+, MITRE ATT&CK, LMS, Canvas, Moodle, Blackboard, D2L, LTI

## Links
- Website: https://redherrings.app
- Download and free trial: https://redherrings.app/download.html
- Live demo: https://redherrings.app/try.html
- Cases: https://redherrings.app/cases.html
- Courses and syllabi: https://redherrings.app/courses.html
- Pricing: https://redherrings.app/#pricing
- Docs: https://redherrings.app/help.html
- Security and trust: https://redherrings.app/trust.html
- Press kit: https://redherrings.app/press.html
