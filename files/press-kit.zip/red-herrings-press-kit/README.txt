Red Herrings press kit
======================

Use anything here without asking. Approved descriptions are in copy/copy.md.

Facts
  Product   Red Herrings, a desktop application for Windows, macOS and Linux
  Does      Generates a different digital forensics or incident response lab for
            every student from one case, with each answer key verified against
            that student's own evidence, one-click grading and LMS export
  Company   The Competence Collective, LLC, Tallahassee, Florida
  Founded   2026
  Pricing   Free First Look cases with no key, a 30-day trial key by email, and
            paid plans for individuals, educators, departments and security
            teams: https://redherrings.app/#pricing
  Privacy   Runs on the instructor's machine; no student data leaves it
  Contact   https://redherrings.app/contact.html

assets/
  logo-240.png, logo-256.png, logo-300.png, logo-512.png   transparent
  logo-512-white.png                                       on white
  social-card-1200x630.png                                 link preview
  x-header-1500x500.png, linkedin-cover-1128x191.png       profile banners
  screenshot-1..6-*-1600x1000.jpg                          app screens
  gallery-1..6-*-1270x760.png                              directory galleries
  syllabus-*.pdf                                           the two course syllabi
  chain-of-custody-form.pdf, forensic-report-checklist.pdf,
  investigation-report-rubric.pdf                          classroom forms
