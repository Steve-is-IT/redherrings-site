# Hacker News: Show HN

One shot. Post on a weekday between 8 and 10 am Eastern, two days after Product Hunt.
Use the URL field for the site and put the founder comment in as the first comment, not the text field.

## Title (80 max)
Show HN: Red Herrings, forensics labs that are different for every student

## URL
https://redherrings.app

## First comment

I teach and run digital forensics training, and the recurring problem is that evidence images are static. The same E01 goes around for years and the answers are on a Discord within weeks.

Red Herrings takes one authored case and generates a different variant per student. The interesting part is not the randomisation, it is the verification. After generating a student's evidence, a separate parser re-opens the files (REGF hives, EVTX, PCAP, the SQLite stores, the memory image) and recomputes every answer from the artifacts. If the recomputed answer does not match the key, the lab does not ship. So an answer in the key is never something the generator asserted; it is something an independent reader found.

Formats are the real ones, so students use Autopsy, Registry Explorer, EvtxECmd, Volatility 3, Wireshark and so on rather than a toy viewer. There is a student portal that grades on submission, timed exams with integrity logging, export to the usual LMSs, and two full course syllabi with free readings.

It is a desktop app that runs offline on the instructor's machine. Commercial, with a free 30-day trial and a free sample lab you can download without installing anything: https://redherrings.app/try.html

Happy to answer questions about how the artifact writers work, which was most of the engineering.
