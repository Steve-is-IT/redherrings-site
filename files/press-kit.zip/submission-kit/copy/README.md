# Red Herrings submission kit

Everything needed to list redherrings.app everywhere that matters, in the order to do it.
Copy is in `copy/`, images and PDFs in `assets/`. Each listing takes 10 to 20 minutes.
Do one a day; a burst looks manufactured and gets some listings rejected.

## The order (four weeks, one item a day)

| Day | Where | File |
|---|---|---|
| 1 | GitHub: awesome-forensics pull request | awesome-lists.md |
| 2 | GitHub: awesome-incident-response pull request | awesome-lists.md |
| 3 | LinkedIn company page | linkedin.md |
| 4 | AlternativeTo | directories.md |
| 5 | SaaSHub and Slant | directories.md |
| 6 | dfir.training | directories.md |
| 7 | CLARK (clark.center) | clark-oer-merlot.md |
| 8 | OER Commons | clark-oer-merlot.md |
| 9 | MERLOT | clark-oer-merlot.md |
| 10 | Forensic Focus vendor profile | directories.md |
| 11 | Capterra (covers GetApp and Software Advice) | directories.md |
| 12 | G2 | directories.md |
| 13 | Crunchbase | directories.md |
| 14 | SourceForge | directories.md |
| 15 | Product Hunt: schedule for the next Tuesday | product-hunt.md |
| 16 | NICCS training catalog | directories.md |
| 17 | Reddit r/computerforensics (resource post) | reddit.md |
| 18 | Email five instructors | outreach-emails.md |
| 19 | Forensic Focus guest post pitch | outreach-emails.md |
| 20 | CISSE and SIGCSE list announcements | outreach-emails.md |
| 21 | Product Hunt launch day | product-hunt.md |
| 22 | Show HN, two days after Product Hunt | hacker-news.md |
| 23 | Reddit r/cybersecurity | reddit.md |
| 24 | Reddit r/AskNetsec (reply-style, not a post) | reddit.md |
| 25 | Uneed, Indie Hackers | directories.md |
| 26 | Ask the first paying departments for a link | outreach-emails.md |
| 27 | LinkedIn: first weekly post | linkedin.md |
| 28 | Record every live URL in docs/LISTINGS-AND-BACKLINKS.md | |

## Identity, identical everywhere

- Name: Red Herrings
- Company: The Competence Collective, LLC (Tallahassee, Florida)
- Website: https://redherrings.app
- Support: https://redherrings.app/contact.html
- Tagline: Forensics and IR labs that grade themselves
- Founded: 2026
- Platforms: Windows, macOS, Linux (desktop)
- Pricing: free 30-day trial, paid plans from the Individual tier (never type amounts into a directory)

## Tracker

Paste the live URL next to each as it goes up.

| Listing | Status | Live URL |
|---|---|---|
| awesome-forensics | | |
| awesome-incident-response | | |
| LinkedIn | | |
| AlternativeTo | | |
| SaaSHub | | |
| Slant | | |
| dfir.training | | |
| CLARK | | |
| OER Commons | | |
| MERLOT | | |
| Forensic Focus | | |
| Capterra / GetApp / Software Advice | | |
| G2 | | |
| Crunchbase | | |
| SourceForge | | |
| Product Hunt | | |
| NICCS | | |
| Hacker News | | |
| Reddit | | |
