# Outreach emails

Plain text, short, one ask each. Send from your own address, not a no-reply.

## 1. Instructor: free semester for a written review

Subject: A semester of Red Herrings for your forensics course, in exchange for an honest review

Hi [Name],

I make Red Herrings, a desktop tool that generates a different digital forensics or incident response lab for every student from one case, with each answer key verified against the student's own evidence. It runs on your machine; no student data leaves it.

I would like to give [Program] an Educator licence for the [Spring 2027] term at no cost. In return I would ask for a short written review on your program page or blog at the end of the term, good or bad, with a link to the site. No approval of the text on my side.

The library has dozens of cases, two full syllabi with free readings, a student portal that grades on submission, and export to [Canvas]. A sample lab you can open today without installing anything is at https://redherrings.app/try.html.

If that is interesting, reply and I will send the key the same day.

[Your name]
The Competence Collective, LLC
https://redherrings.app

## 2. Forensic Focus or a DFIR newsletter: guest post pitch

Subject: Guest post: running a graded forensics course where every student has different evidence

Hi [Editor],

I would like to offer a piece for [Forensic Focus / This Week in 4n6 / DFIR Diva] on a practical problem: static evidence images leak their answer keys, and a lab then measures who has the link.

The post would cover how to run a graded course with per-student evidence: what has to vary (names, hosts, timestamps, hashes, answers), what must not (the story and the skills), how to verify an answer key against generated artifacts rather than asserting it, and how to grade with tolerances. About 1,200 words, no product pitch in the body, one disclosure line and a link in the bio. I built Red Herrings, which does this, so the examples are from real artifact writers.

Happy to send a draft or an outline first.

[Your name]
https://redherrings.app

## 3. CISSE and SIGCSE mailing lists: one announcement

Subject: Tool announcement: per-student digital forensics and incident response labs with verified answer keys

Red Herrings is a desktop application (Windows, macOS, Linux) that generates a different variant of a forensics or incident response case for every student, in real evidence formats, and verifies each answer key against the generated files before the lab ships. It grades on submission, exports to Canvas, Blackboard, Moodle and D2L, and runs entirely on the instructor's machine.

Two complete course syllabi with free readings and a set of classroom forms are available at no cost at https://redherrings.app/courses.html whether or not you use the labs. A free 30-day trial and a sample lab are at https://redherrings.app.

I am the author and would welcome feedback from instructors. Please reply off-list.

[Your name], The Competence Collective, LLC

## 4. Paying department: a link on the program page

Subject: Small favour: a "tools we use" link

Hi [Name],

Thank you for running [Course] on Red Herrings this term. If your program page has a place for tools or partners, a one-line mention with a link would help us a lot with other departments finding it:

Red Herrings, per-student digital forensics labs: https://redherrings.app

And if there is anything that would make next term easier, tell me and I will build it.

[Your name]
