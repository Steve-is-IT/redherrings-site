# Listings, directories and backlinks

A working checklist for getting redherrings.app listed where instructors,
students and DFIR people actually look, with copy ready to paste. Every entry
needs an account the owner holds, so this is a to-do list, not automation.
Tick the box and note the live URL when a listing is up.

Assets to upload (all in the site repo):

| Asset | File | Size |
|---|---|---|
| Logo, square | `img/icon-512.png` | 512 x 512 PNG |
| Social card | `img/og/home-e73cb8ed.png` (regenerate with `tools-og-cards.py`; the name changes with the content) | 1200 x 630 PNG |
| Screenshots | `img/slides/slide-library.jpg`, `slide-case.jpg`, `slide-generate.jpg`, `slide-grading.jpg`, `slide-results.jpg`, `slide-pathways.jpg` | 1600 x 1000 JPG |
| Demo video | the one on the home page (check `index.html` for the current file) | |

## Pasteable copy

**Name:** Red Herrings

**Tagline (60 chars):** Forensics and IR labs that grade themselves

**One line (120 chars):** Digital forensics and incident response labs with a different case for every student and a verified answer key.

**Short (160 chars):** Generate per-student digital forensics and incident response labs with verified answer keys, one-click grading and LMS export. Runs offline on your machine.

**Medium (about 60 words):** Red Herrings generates digital forensics and incident response lab exercises for a whole class in minutes. Every student gets a different variant of the case: names, timestamps, hashes and answers change per student, so a copied answer is a wrong answer. Each answer key is re-derived from the generated evidence before the lab ships. Grades export to Canvas, Blackboard, Moodle and D2L.

**Long (about 180 words):** Red Herrings is a desktop application for Windows, macOS and Linux that turns one authored case into an individually generated lab for every student. The evidence is real: disk images, registry hives, Windows event logs, Windows memory images, packet captures, mobile extractions, cloud audit logs, and EDR and SIEM exports, written in the formats the standard tools open. Names, timestamps, hashes, addresses and answers change per student from a single seed, so students cannot share answers and instructors can tell when they tried. Every answer key is verified against the generated files by an independent parser before release.

Grading takes one click, with tolerances for hashes and timestamps and an explanation for every score, and exports to Canvas, Blackboard, Moodle and D2L or posts over LTI 1.3. The library holds dozens of cases from single-artifact First Looks to multi-day capstones, tagged to GIAC, CompTIA, EnCE and Cellebrite objectives and to MITRE ATT&CK, with learning pathways, two course packs with full syllabi (outcomes, free readings, policies, rubric), a guided mode for stuck learners and timed exams. Everything runs on the instructor's own machine; no student data leaves it. Free 30-day trial, no account required.

**Categories to pick:** Education, Cybersecurity, Digital Forensics, Incident Response, E-Learning, Training, Course Authoring, Lab Management.

**Tags:** digital forensics, incident response, DFIR, cybersecurity education, forensics lab, SOC training, GCFE, GCIH, CompTIA CySA+, MITRE ATT&CK, LMS, Canvas, Moodle.

**Pricing to enter:** Free trial; paid plans from the Individual tier; see redherrings.app/#pricing (do not type amounts into directories, they go stale).

**Links:** Website https://redherrings.app, Courses and syllabi https://redherrings.app/courses.html, Pricing https://redherrings.app/#pricing, Free trial https://redherrings.app/download.html, Live demo https://redherrings.app/try.html, Docs https://redherrings.app/help.html.

## Tier 1: do these first (free, high relevance, real links)

- [ ] **GitHub awesome lists.** Open a pull request adding one line to each. These are followed links from high-authority repos and the DFIR community reads them.
  - `cugu/awesome-forensics` (section: Learn Forensics / Challenges or Education): `- [Red Herrings](https://redherrings.app) - Generates per-student digital forensics and incident response labs with verified answer keys; evidence in real formats (E01, hives, EVTX, PCAP, memory).`
  - `meirwah/awesome-incident-response` (section: Training or Playbooks): `- [Red Herrings](https://redherrings.app) - Incident response lab generator: EDR and SIEM evidence per student, mapped to ATT&CK and NIST 800-61, auto-graded.`
  - `rshipp/awesome-malware-analysis` is not a fit; skip.
- [ ] **CLARK (clark.center)**, the cybersecurity curriculum library used by NSA CAE schools. Contribute the two free syllabi and the chain of custody, report checklist and rubric PDFs as a learning object with a link back. This is the single most relevant education backlink available.
- [ ] **OER Commons (oercommons.org)**: list the free resources page and both syllabi as open educational resources. Followed links, education authority.
- [ ] **MERLOT (merlot.org)**: same materials, "Computer Science / Cybersecurity".
- [ ] **dfir.training** tools directory: submit under Training / Education.
- [ ] **Forensic Focus** (forensicfocus.com): create a vendor profile and post the sample lab in the forum's training section once; they also accept product news.
- [ ] **AlternativeTo**: add the app; suggest "alternative to" building labs by hand and to hosted cyber ranges. Fast to approve, decent referral traffic.
- [ ] **SaaSHub** and **Slant**: add listing; both approve same day.
- [ ] **Product Hunt**: schedule a launch for a Tuesday or Wednesday; use the demo video, five screenshots, the one-line and the long copy. Ask the Discord to upvote and comment on launch morning. Even a modest launch yields a permanent followed link and a week of traffic.
- [ ] **LinkedIn company page** for Red Herrings with the long copy, logo and website; then post the compare page and one blog post a week from it.

## Tier 2: software directories (free tiers)

- [ ] **Capterra / GetApp / Software Advice** (one submission covers all three): category "Computer Security Software" and "Training Software". Free listing, paid placement optional; skip paid.
- [ ] **G2**: category "Cybersecurity Training" or "Technical Skills Development". Free profile. They will ask for reviews; ask the first few paying customers.
- [ ] **Crunchbase**: company profile for The Competence Collective, LLC with Red Herrings as the product.
- [ ] **SourceForge** and **Slashdot software directory**: create a product page even though the app is not open source; the followed link is the point.
- [ ] **Uneed**, **BetaList** (if positioned as new), **Indie Hackers** product page.

## Tier 3: education and cybersecurity community

- [ ] **NICE Challenge / NICCS** education and training catalog (niccs.cisa.gov): submit as a training provider. Free, government domain.
- [ ] **CAE Community (caecommunity.org)** resources: post the free resources in the member forum if you can get an account through a partner school.
- [ ] **ISACA / (ISC)2 / SANS community forums**: no self-promotion rules vary; answer instructor questions and link the free resources where relevant.
- [ ] **Reddit**: r/computerforensics, r/cybersecurity, r/AskNetsec, r/ITCareerQuestions. Read each sub's self-promotion rule. The pattern that works: post the free PDFs or a tool guide blog post as a resource, with the product mentioned once in the body, not the title.
- [ ] **Hacker News**: a "Show HN: Red Herrings, forensics labs that are different for every student" post with a two-paragraph founder comment explaining the verification trick. One shot; do it after Product Hunt.
- [ ] **Cybersecurity educator mailing lists**: the CISSE and the SIGCSE lists accept tool announcements once.

## Tier 4: outreach that earns editorial links (slow, best quality)

- [ ] Email five community college and university forensics instructors found through the Florida letter campaign and offer a free Educator license for a semester in exchange for a short written review on their program page or blog.
- [ ] Offer a guest post to Forensic Focus and to a DFIR newsletter (This Week in 4n6, DFIR Diva) about running a graded forensics course with per-student evidence.
- [ ] Ask the first three paying departments for a logo-and-link on their program page under "tools we use".

## Already done

- Google Search Console verified; sitemap submitted.
- IndexNow (Bing and partners) pinged on every site push.
- Structured data: Organization, SoftwareApplication with version and download URL, FAQPage on the home page, HowTo on how-it-works, BlogPosting on every article.
- Open Graph and Twitter cards on every page.

## Anchor text

Keep the link text looking like what real people write. Target mix over all
backlinks: about half plain brand (Red Herrings, redherrings.app), a quarter
brand plus descriptor (Red Herrings forensics lab generator), 15 percent varied
partial-match phrases, the rest naked URLs or generic words.

Where each kind goes:

- GitHub awesome lists: anchor `Red Herrings`, keywords in the description.
- Directories: brand anchors by design; nothing to choose.
- CLARK, OER Commons, MERLOT: link the resources page with a resource-shaped
  anchor such as "free digital forensics course syllabus and classroom forms".
- Forums and Reddit: brand or naked URL only, written like a person.
- Guest posts and newsletters: one in-body partial-match anchor to the page
  that targets that phrase, plus a brand link in the bio.
- Customer program pages: brand plus a one-line descriptor.

Partial-match phrases to use once each, pointed at the matching page:

1. digital forensics labs for students (home)
2. incident response training labs (/incident-response.html)
3. auto-graded forensics labs (/student-portal.html)
4. forensics lab generator (/how.html)
5. DFIR practice cases with answer keys (/cases.html)
6. GCFE practice labs, GCIH practice labs (/pathways.html, cert contexts only)

Never repeat the same partial-match anchor from two different sites, never
"click here", and never send keyword anchors to the home page.

## Rules of thumb

- Never pay for a directory listing or a "backlink package". Those links are ignored or penalised.
- One listing a day is plenty; a burst of fifty in a week looks manufactured.
- Keep the name, tagline and description identical everywhere; consistency helps Google tie the listings to the site.
- Record every live listing URL here so profiles can be updated at each release.
