# LinkedIn

## Company page
- Name: Red Herrings
- Tagline: Forensics and IR labs that grade themselves
- Industry: E-Learning Providers (or Computer and Network Security)
- Company size: 1-10
- Type: Privately held
- Founded: 2026
- Website: https://redherrings.app
- Logo: assets/logo-300.png
- Cover: assets/linkedin-cover-1128x191.png
- About: copy.md, Long

## Launch post (Product Hunt day)

Every forensics course I have seen runs on the same handful of evidence images, and the answer keys leak within a semester.

Red Herrings generates a different variant of each case for every student, in the real formats, and verifies every answer key against the generated evidence before the lab ships. One-click grading, LMS export, timed exams, two full course syllabi. It runs on the instructor's own machine.

Free 30-day trial, no account: https://redherrings.app

If you teach digital forensics or incident response, I would like to hear which case you wish existed.

## Four weekly posts (one idea each, with a link to the matching page)

1. The verification trick: why an answer key that is asserted is worth less than one that is re-derived. Link: https://redherrings.app/how.html
2. Two free syllabi with weekly readings from NIST, SANS and the tool maintainers. Link: https://redherrings.app/courses.html
3. Running a timed SOC drill: 45 minutes, integrity logging, ATT&CK mapping. Link: https://redherrings.app/security-teams.html
4. The student portal and grade passback to Canvas, Blackboard, Moodle and D2L. Link: https://redherrings.app/student-portal.html
