# Product Hunt

Schedule for a Tuesday or Wednesday, 12:01 am Pacific. Set it up the week before.

## Fields
- Name: Red Herrings
- Tagline (60 max): Forensics and IR labs that grade themselves
- Links: https://redherrings.app (website), https://redherrings.app/download.html (download)
- Topics: Education, Developer Tools, Security, SaaS (pick the three it allows)
- Description (260 max):
  Generate a different digital forensics or incident response lab for every student from one case. Real evidence, a verified answer key per student, one-click grading, LMS export. Runs on your machine. Free 30-day trial.
- Pricing: Free trial, then paid
- Thumbnail: assets/logo-240.png (animated GIF not needed)
- Gallery, in this order: assets/gallery-1-library-1270x760.png, gallery-3-generate, gallery-4-results, gallery-5-grading, gallery-2-case, gallery-6-pathways
- First comment: below. Post it the second the launch goes live.
- Makers: you. Add a co-maker only if real.

## First comment (maker story)

Hi Product Hunt. I built Red Herrings because every forensics class I have seen runs on the same two or three evidence images, and the answer keys are on the internet within a semester.

Red Herrings generates a different variant of a case for every student. Names, hosts, timestamps, hashes and answers all change from a single seed, so two students sitting together have different evidence and different keys. The evidence is written in the real formats: disk images, registry hives, Windows event logs, memory captures, packet captures, iOS extractions, cloud audit logs, EDR and SIEM exports. Each answer key is re-derived from the generated files by an independent parser before the lab ships, so an answer is never asserted, only proven.

Grading is one click, with tolerances for hashes and timestamps and an explanation per score, and exports to Canvas, Blackboard, Moodle and D2L. There are dozens of cases from 25-minute First Looks to multi-day capstones, mapped to GIAC and CompTIA objectives and MITRE ATT&CK, two course packs with full syllabi, timed exams with integrity logging, and a CTF mode.

It runs entirely on the instructor's machine. No student data leaves it.

Free 30-day trial, no account. I would love to hear what cases you want next.

## Launch day checklist
- [ ] Post the first comment immediately.
- [ ] Message the Discord and ask people to try it and leave an honest comment, not just an upvote.
- [ ] Reply to every comment within an hour for the first 12 hours.
- [ ] Post the launch on LinkedIn (linkedin.md, launch post) mid-morning Eastern.
- [ ] Two days later: Show HN (hacker-news.md).
