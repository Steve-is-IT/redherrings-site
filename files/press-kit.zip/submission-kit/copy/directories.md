# Directories, field by field

Everything below uses copy.md. Logo: assets/logo-512.png (or logo-512-white.png where transparency
is rejected). Screenshots: assets/screenshot-*.jpg. Never buy a placement.

## AlternativeTo
- Name: Red Herrings. Category: Education and Reference / Security.
- Platforms: Windows, Mac, Linux. Licence: Commercial (free trial).
- Description: copy.md Medium.
- Tags: digital-forensics, incident-response, cybersecurity-training, lab-generator, education
- "Alternative to": list it as an alternative to Hack The Box, TryHackMe, CyberDefenders and Immersive Labs (the hosted-range category), and note the difference in one line: runs offline on the instructor's machine with a different variant per student.

## SaaSHub
- Name, website, tagline (copy.md Tagline), description (Medium), category: Education / Security.
- Alternatives: same four as above.

## Slant
- Add to "What are the best platforms for learning digital forensics?" and "best SOC analyst training". Pro: different evidence per student with verified keys. Con: desktop app, instructor runs it.

## dfir.training
- Submit a tool under Training / Education. Name, URL, one line (copy.md One line), category Training, cost: Commercial with free trial.

## Forensic Focus
- Vendor profile: company name, logo, website, Long copy.
- One forum post in the Education / Training section: the free sample lab (https://redherrings.app/try.html) and the syllabi, written as a resource, product named once.
- Product news: send the 1.10 release (Home screen, role paths, full syllabi) as a short news item.

## Capterra (also populates GetApp and Software Advice)
- Product name: Red Herrings. Vendor: The Competence Collective, LLC.
- Categories: Computer Security Software; Training Software; Learning Management Systems (if offered, decline; it is not an LMS).
- Short description (copy.md Short). Long description (Long).
- Deployment: Windows, Mac, Linux desktop. Support: email, documentation. Training: documentation, videos.
- Pricing: free trial yes; starting price: do not enter; link to pricing page.
- Features to tick: assessment management, course authoring, gradebook, LMS integration (LTI), offline access, reporting and analytics, certification and licensing, tests and assessments.
- Decline the paid PPC placement.

## G2
- Category: Cybersecurity Training (or Technical Skills Development). Same copy. Upload six screenshots.
- G2 asks for reviews to publish fully; ask the first paying customers, never friends.

## Crunchbase
- Organization: The Competence Collective, LLC. Founded 2026, Tallahassee, Florida. Industries: Cyber Security, EdTech, Software. Products: Red Herrings with website.

## SourceForge and Slashdot
- Create a product page (not a project): name, Long copy, screenshots, website, licence: commercial. The followed link is the point.

## NICCS (niccs.cisa.gov) Education and Training catalog
- Provider: The Competence Collective, LLC. Course entries: use the two syllabi as the two courses, with the NICE work roles from clark-oer-merlot.md. Delivery: self-paced, instructor-led. Cost: commercial.

## Uneed, Indie Hackers
- Same tagline, Short copy, logo-512, three screenshots. Indie Hackers product page can link the Product Hunt launch.
