# Curriculum libraries: CLARK, OER Commons, MERLOT

These accept free educational materials with a link back. Submit the two syllabi and the three
classroom forms as one collection. Choose a licence before submitting; CC BY 4.0 is the usual
choice and matches "may be copied into institutional templates" in the syllabi.

## Shared metadata
- Title: Digital Forensics and Incident Response Course Materials: two syllabi, classroom forms and rubric
- Author / contributor: The Competence Collective, LLC (Red Herrings)
- Audience: Undergraduate, graduate, professional training
- Subject: Computer science; Cybersecurity; Digital forensics; Incident response
- Material type: Syllabus, Assessment, Course outline
- Language: English
- Licence: CC BY 4.0 (your call)
- Files: assets/syllabus-intro-digital-forensics-14.pdf, assets/syllabus-incident-response-fundamentals-8.pdf, assets/chain-of-custody-form.pdf, assets/forensic-report-checklist.pdf, assets/investigation-report-rubric.pdf
- Link back: https://redherrings.app/resources.html with anchor text "free digital forensics course syllabus and classroom forms"

## Description (all three)
Two complete course syllabi and three classroom forms for teaching digital forensics and incident response with hands-on labs. The 14-week Introduction to Digital Forensics syllabus covers Windows artifacts, timelines, browser, cloud, memory, network and mobile evidence and ends in a timed capstone and written report. The 8-week Incident Response Fundamentals syllabus runs from reading one EDR alert to a ransomware incident worked through every NIST 800-61 phase, mapped to MITRE ATT&CK. Each syllabus includes learning outcomes, prerequisites, a software table of free tools, free readings per week from NIST, CISA, MITRE, Microsoft and the tool maintainers, an assessment scheme with weights and grading scale, course policies, a week-by-week plan with objectives, preparation, deliverables and instructor notes, and a report rubric. The forms are a chain-of-custody record, a forensic report checklist and an investigation report rubric. The labs referenced generate a different variant per student; the syllabus text, policies and rubric are usable with any lab evidence.

## CLARK specifics
- Collection: CAE Community or Plan C, whichever your account can post to.
- Learning object level: Course (14-week) and Unit (8-week).
- Map outcomes to the NICE Framework work roles: Cyber Defense Forensics Analyst (IN-FOR-002), Cyber Defense Incident Responder (PR-CIR-001).

## MERLOT specifics
- Category: Science and Technology > Computer Science > Cybersecurity
- Material type: Syllabus / Course Outline; Assessment Tool
- Primary audience: College Upper Division, Graduate School, Professional
