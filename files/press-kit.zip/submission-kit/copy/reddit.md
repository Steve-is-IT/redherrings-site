# Reddit

Read each sub's self-promotion rule the day you post. The pattern that survives: lead with the free
resource, mention the product once in the body, never in the title, and answer every comment.

## r/computerforensics (resource post)

Title: Free forensics course syllabus (14 weeks) with weekly readings from NIST, SANS posters and tool docs

Body:
I put together a 14-week Introduction to Digital Forensics syllabus that I think is complete enough to teach from: outcomes, a week-by-week plan, free readings for every week (NIST SP 800-86 and 800-101, the SANS posters, the Zimmerman tool docs, Volatility 3 and Wireshark guides), an assessment scheme, policies and a report rubric. There is an 8-week incident response one alongside it built on NIST 800-61 and ATT&CK.

PDFs are free here: https://redherrings.app/courses.html

The labs in the syllabus are from Red Herrings, which I make; the syllabus text, policies and rubric are usable without it and I would rather people take them than not. If you teach, I would like to know what you would change.

## r/cybersecurity (discussion post)

Title: How do you stop answer-sharing in hands-on forensics and IR labs?

Body:
Honest question for people who teach or run training. Every static evidence image I have used eventually leaks its answer key, and then the lab measures who has the Discord link.

The approach I ended up building is generating a different variant of each case per student from one seed, and verifying every answer key against the generated evidence with a separate parser before release. It works, but it took a lot of engineering on the artifact writers.

What do others do? Rotating images, honour codes, oral defences, live demos? Curious what actually holds up.

(Disclosure: this became a product, Red Herrings, but I am asking about the problem, not pitching.)

## r/AskNetsec (reply, not a post)

Do not post. Search the sub for threads asking about "forensics training", "practice images", "SOC analyst practice" or "incident response exercises", and reply with the free sample lab or the syllabi where they genuinely answer the question. One link, written like a person.
