# GitHub awesome lists

Two pull requests, each adding one line. Both repos accept edits through the GitHub web editor,
which forks automatically. Followed links from high-authority repos the DFIR community reads.

## 1. cugu/awesome-forensics

Edit link (opens the web editor and forks for you; sign in to GitHub first or it shows a 404):
https://github.com/cugu/awesome-forensics/edit/main/README.md

Find the `### Labs` heading near the end (under `## Resources`). It currently has one entry
(BlueTeam.Lab). Add this line after it, keeping the list alphabetical:

```
- [Red Herrings](https://redherrings.app) - Generates a different digital forensics or incident response lab per student from one case, with evidence in real formats (disk, registry hives, EVTX, memory, PCAP, mobile, cloud) and a verified answer key.
```

Pull request title:
```
Add Red Herrings to Labs
```

Pull request body:
```
Adds Red Herrings under Resources / Labs: a desktop tool that generates per-student forensics and incident response labs from one case. Evidence is produced in the real formats (E01 and raw images, REGF hives, EVTX, memory captures, PCAP, iOS extractions, cloud audit logs) and each answer key is verified against the generated files. Free 30-day trial; commercial product, disclosed as the author.
```

## 2. meirwah/awesome-incident-response

Edit link:
https://github.com/meirwah/awesome-incident-response/edit/master/README.md

This list uses `*` bullets and alphabetical order within a section. Add under `### Other Tools`,
in alphabetical position (after the entry beginning with a letter before R, before any beginning with S):

```
* [Red Herrings](https://redherrings.app) - Generates a different incident response lab per analyst from one case: EDR, SIEM and proxy evidence mapped to MITRE ATT&CK and NIST 800-61, with a verified answer key, timed drills and auto-grading.
```

Also add the same line to the Contents-linked section if the list keeps a table of contents entry count (it does not; the TOC lists sections only).

Pull request title:
```
Add Red Herrings to Other Tools
```

Pull request body:
```
Adds Red Herrings under Other Tools: a desktop tool that generates per-analyst incident response labs (EDR alert feeds, SIEM exports, proxy and firewall logs, Windows event logs) mapped to ATT&CK and the NIST 800-61 lifecycle, each with a verified answer key and timed-exam mode. Free 30-day trial; commercial product, disclosed as the author.
```

## If a maintainer asks

Both lists prefer tools over products but accept commercial entries with free tiers when they are
clearly useful and disclosed. If asked, point at the free sample lab (https://redherrings.app/try.html)
and the free syllabi and forms (https://redherrings.app/resources.html).
