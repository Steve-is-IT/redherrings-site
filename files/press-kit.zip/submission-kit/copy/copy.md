# Copy, by length

Use these verbatim. Consistency across listings is how search engines tie them to the site.

## Name
Red Herrings

## Tagline (45 characters)
Forensics and IR labs that grade themselves

## One line (120 characters)
Digital forensics and incident response labs with a different case for every student and a verified answer key.

## Short (160 characters)
Generate per-student digital forensics and incident response labs with verified answer keys, one-click grading and LMS export. Runs offline on your machine.

## Medium (about 60 words)
Red Herrings generates digital forensics and incident response lab exercises for a whole class in minutes. Every student gets a different variant of the case: names, timestamps, hashes and answers change per student, so a copied answer is a wrong answer. Each answer key is re-derived from the generated evidence before the lab ships. Grades export to Canvas, Blackboard, Moodle and D2L.

## Long (about 190 words)
Red Herrings is a desktop application for Windows, macOS and Linux that turns one authored case into an individually generated lab for every student. The evidence is real: disk images, registry hives, Windows event logs, memory captures, packet captures, mobile extractions, cloud audit logs, and EDR and SIEM exports, written in the formats the standard tools open. Names, timestamps, hashes, addresses and answers change per student from a single seed, so students cannot share answers and instructors can tell when they tried. Every answer key is verified against the generated files by an independent parser before release.

Grading takes one click, with tolerances for hashes and timestamps and an explanation for every score, and exports to Canvas, Blackboard, Moodle and D2L or posts over LTI 1.3. The library holds dozens of cases from single-artifact First Looks to multi-day capstones, tagged to GIAC, CompTIA, EnCE and Cellebrite objectives and to MITRE ATT&CK, with learning pathways, two course packs with full syllabi, a guided mode for stuck learners and timed exams with integrity logging. Everything runs on the instructor's own machine; no student data leaves it. Free 30-day trial, no account required.

## Who it is for (one line each)
- Instructors teaching a digital forensics or incident response class.
- Departments and programs running a syllabus across several instructors.
- Security teams training analysts with timed drills and CTFs.
- Self-learners preparing for GCFE, GCFA, GCIH or CySA+.

## Categories
Education, Cybersecurity, Digital Forensics, Incident Response, E-Learning, Training, Course Authoring, Lab Management

## Tags
digital forensics, incident response, DFIR, cybersecurity education, forensics lab, SOC training, GCFE, GCIH, CompTIA CySA+, MITRE ATT&CK, LMS, Canvas, Moodle, Blackboard, D2L, LTI

## Links
- Website: https://redherrings.app
- Free trial: https://redherrings.app/download.html
- Live demo: https://redherrings.app/try.html
- Cases: https://redherrings.app/cases.html
- Courses and syllabi: https://redherrings.app/courses.html
- Pricing: https://redherrings.app/#pricing
- Docs: https://redherrings.app/help.html
- Security and trust: https://redherrings.app/trust.html
- Press kit: https://redherrings.app/press.html
