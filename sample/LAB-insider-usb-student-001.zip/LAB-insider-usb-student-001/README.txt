Red Herrings lab package
========================

Case ID     : RH-2026-7430--001
Student     : Student 1
Scenario    : Insider Data Theft via USB
Difficulty  : medium
Host        : OAKMON-WS32 (Windows 10 Pro)
Evidence    : 19 files under evidence/

Steps:
  1. Read the worksheet briefing.
  2. Verify each evidence file against HASH-MANIFEST.txt before you begin.
  3. Work the questions, citing where in the evidence you found each answer.
  4. Submit your answers in the format your instructor requested.

Every student receives a different variant of this case. Your answers are
specific to the evidence in this package.

Generated with Red Herrings (redherrings.app)
